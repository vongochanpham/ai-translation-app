import 'package:flutter/material.dart';
import 'package:dart_openai/dart_openai.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:country_flags/country_flags.dart';


class LanguageTranslationPage extends StatefulWidget {
  const LanguageTranslationPage({super.key});

  @override
  State<LanguageTranslationPage> createState() => _LanguageTranslationPageState();
}

class _LanguageTranslationPageState extends State<LanguageTranslationPage> {
  final Map<String, String> languages = {
    'Afrikaans': 'af',                // Afrikaans
    'Albanian': 'sq',                 // Albanian
    'Arabic': 'ar',                   // Arabic
    'Armenian': 'hy',                 // Armenian
    'Azerbaijani': 'az',              // Azerbaijani
    'Bengali': 'bn',                  // Bengali
    'Bosnian': 'bs',                  // Bosnian
    'Bulgarian': 'bg',                // Bulgarian
    'Catalan': 'ca',                  // Catalan
    'Chinese (Simplified)': 'cn',     // Chinese (Simplified, China)
    'Chinese (Traditional)': 'tw',     // Chinese (Traditional, Taiwan)
    'Croatian': 'hr',                 // Croatian
    'Czech': 'cs',                    // Czech
    'Danish': 'da',                   // Danish
    'Dutch': 'nl',                    // Dutch
    'English': 'us',                  // English (United States)
    'Estonian': 'et',                 // Estonian
    'Finnish': 'fi',                  // Finnish
    'French': 'fr',                   // French
    'Galician': 'gl',                 // Galician
    'Georgian': 'ka',                 // Georgian
    'German': 'de',                   // German
    'Greek': 'el',                    // Greek
    'Gujarati': 'gu',                 // Gujarati
    'Haitian Creole': 'ht',           // Haitian Creole
    'Hebrew': 'he',                   // Hebrew
    'Hindi': 'India',                    // Hindi
    'Hungarian': 'hu',                // Hungarian
    'Icelandic': 'is',                // Icelandic
    'Indonesian': 'id',               // Indonesian
    'Irish': 'ga',                    // Irish
    'Italian': 'it',                  // Italian
    'Japanese': 'jp',                 // Japanese
    'Javanese': 'jw',                 // Javanese
    'Kazakh': 'kk',                   // Kazakh
    'Korean': 'kr',                   // Korean
    'Kurdish (Kurmanji)': 'ku',       // Kurdish (Kurmanji)
    'Kyrgyz': 'ky',                   // Kyrgyz
    'Latvian': 'lv',                  // Latvian
    'Lithuanian': 'lt',               // Lithuanian
    'Luxembourgish': 'lb',            // Luxembourgish
    'Macedonian': 'mk',               // Macedonian
    'Malay': 'ms',                    // Malay
    'Maltese': 'mt',                  // Maltese
    'Maori': 'mi',                    // Maori
    'Marathi': 'mr',                  // Marathi
    'Mongolian': 'mn',                // Mongolian
    'Nepali': 'ne',                   // Nepali
    'Norwegian': 'no',                // Norwegian
    'Pashto': 'ps',                   // Pashto
    'Persian': 'fa',                  // Persian
    'Polish': 'pl',                   // Polish
    'Portuguese': 'pt',               // Portuguese (Portugal)
    'Portuguese (Brazilian)': 'br',   // Portuguese (Brazil)
    'Punjabi': 'pa',                  // Punjabi
    'Romanian': 'ro',                 // Romanian
    'Russian': 'ru',                  // Russian
    'Serbian': 'sr',                  // Serbian
    'Slovak': 'sk',                   // Slovak
    'Slovenian': 'sl',                // Slovenian
    'Spanish': 'es',                  // Spanish
    'Swahili': 'sw',                  // Swahili
    'Swedish': 'sv',                  // Swedish
    'Tamil': 'ta',                    // Tamil
    'Telugu': 'te',                   // Telugu
    'Thai': 'th',                     // Thai
    'Turkish': 'tr',                  // Turkish
    'Ukrainian': 'uk',                // Ukrainian
    'Urdu': 'ur',                     // Urdu
    'Uzbek': 'uz',                    // Uzbek
    'Vietnamese': 'vn',               // Vietnamese
    'Welsh': 'cy',                    // Welsh
    'Xhosa': 'xh',                    // Xhosa
    'Yiddish': 'yi',                  // Yiddish
    'Zulu': 'zu',                     // Zulu
    // Add more languages as needed
  };

  final List<String> translationTypes = [
    'General Conversation',
    'Business',
    'Technical',
    'Medical',
    'Legal',
    'Slang',
    'Academic',
  ];


  String originLanguage = "From";
  String destinationLanguage = "To";
  String selectedTranslationType = 'General Conversation'; // Default translation type
  String output = "";
  final TextEditingController languageController = TextEditingController();
  final speechToText = SpeechToText();
  final flutterTts = FlutterTts();
  String lastWords = '';
  String? generatedContent;
  String? generatedImageUrl;
  bool isListening = false;



  @override
  void initState() {
    super.initState();
    initSpeechToText();
    initTextToSpeech();
    OpenAI.apiKey =
    "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"; // Replace with your OpenAI API key
  }

  Future<void> initTextToSpeech() async {
    await flutterTts.setSharedInstance(true);
    setState(() {});
  }

  Future<void> initSpeechToText() async {
    await speechToText.initialize();
    setState(() {});
  }

  Future<void> startListening() async {
    await speechToText.listen(onResult: onSpeechResult);
    setState(() {
      isListening = true;
    });
  }

  Future<void> stopListening() async {
    await speechToText.stop();
    setState(() {
      isListening = false;
    });
  }

  void onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      lastWords = result.recognizedWords;
      languageController.text =
          lastWords; // Update input text with recognized words
    });
  }

  Future<void> systemSpeak(String content) async {
    await flutterTts.speak(content);
  }

  @override
  void dispose() {
    super.dispose();
    speechToText.stop();
    flutterTts.stop();
  }

  Future<void> translate(String input) async {
    if (originLanguage == "From" || destinationLanguage == "To" || input.isEmpty) {
      setState(() {
        output = "Please select languages, translation type, and enter text to translate.";
      });
      return;
    }

    String prompt = 'Translate the following text from $originLanguage to $destinationLanguage in a $selectedTranslationType context: $input';

    try {
      final chat = await OpenAI.instance.chat.create(
        model: "gpt-3.5-turbo",
        messages: [
          OpenAIChatCompletionChoiceMessageModel(
            role: OpenAIChatMessageRole.user,
            content: [
              OpenAIChatCompletionChoiceMessageContentItemModel.text(prompt)
            ],
          ),
        ],
      );

      final message = chat.choices.first.message;

      if (message.content != null && message.content!.isNotEmpty) {
        setState(() {
          output = message.content?.first.text ?? "Translation returned null.";
        });
        systemSpeak(output);
      } else {
        setState(() {
          output = "No translation found.";
        });
      }
    } catch (e) {
      setState(() {
        output = "Translation failed: ${e.toString()}";
      });
    }
  }

  void swapLanguages() {
    setState(() {
      String temp = originLanguage;
      originLanguage = destinationLanguage;
      destinationLanguage = temp;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Language Translator"),
        centerTitle: true,
        backgroundColor: const Color(0xFFFFB300),
        elevation: 0,
      ),
      body: SingleChildScrollView( // Moved here
        child: Center(
          child: Column(
            children: <Widget>[
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 150, // Fixed width for both dropdown containers
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Color(0xFFFFB300), // Background color for the box
                        borderRadius: BorderRadius.circular(8), // Rounded corners if needed
                      ),
                      child: _buildLanguageDropdown(originLanguage, (value) {
                        setState(() {
                          originLanguage = value!;
                        });
                      }),
                    ),
                  ),
                  const SizedBox(width: 10), // Space between the dropdown and the swap button
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white, // Background color for the button
                      shape: BoxShape.circle, // Circular shape for the button
                    ),
                    child: IconButton(
                      onPressed: swapLanguages,
                      icon: const Icon(Icons.swap_horiz, color: Color(0xFFFFB300), size: 30),
                      tooltip: "Swap languages", // Tooltip for the button
                    ),
                  ),
                  const SizedBox(width: 10), // Space between the swap button and second dropdown
                  SizedBox(
                    width: 150, // Fixed width for both dropdown containers
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Color(0xFFFFB300), // Background color for the box
                        borderRadius: BorderRadius.circular(8), // Rounded corners if needed
                      ),
                      child: _buildLanguageDropdown(destinationLanguage, (value) {
                        setState(() {
                          destinationLanguage = value!;
                        });
                      }),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),
              Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width * 0.9, // 90% of the screen width
                height: 200, // Set a specific height for both boxes
                child: TextFormField(
                  controller: languageController,
                  minLines: 10, // Ensure the same minLines
                  maxLines: null, // Allow the field to expand
                  decoration: const InputDecoration(
                    labelText: 'Please enter or speak your text...',
                    labelStyle: const TextStyle(
                        fontSize: 20, color: Colors.black),
                    // Increased font size
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFFFB300), width: 1),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFFFB300), width: 5),
                    ),
                    errorStyle: const TextStyle(
                        color: Colors.red, fontSize: 15),
                  ),
                ),
              ),
               const SizedBox(height: 20),

              // Row for mic, translation type, and Translate button
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(isListening ? Icons.mic : Icons.mic_none),
                    onPressed: isListening ? stopListening : startListening,
                    color: Color(0xFFFFB300),
                    iconSize: 40,
                    tooltip: isListening ? "Stop Listening" : "Start Speaking",
                  ),
                  const SizedBox(width: 10),
                  Container(
                    decoration: BoxDecoration(
                      color: Color(0xFFFFE57F), // Background color for the dropdown
                      borderRadius: BorderRadius.circular(8), // Optional: rounded corners
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 12), // Optional: add padding inside the container
                    child: DropdownButton<String>(
                    value: selectedTranslationType,
                    items: translationTypes.map((String type) {
                      return DropdownMenuItem(
                        value: type,
                        child: Text(type),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedTranslationType = newValue!;
                      });
                    },
                    dropdownColor: Color(0xFFFFE57F),
                    underline: Container(),
                    iconEnabledColor: Color(0xFFFFB300),
                    style: TextStyle(color: Colors.black, fontSize: 16),
                  ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFB300)),
                    onPressed: () {
                      translate(languageController.text.trim());
                    },
                    child: const Text("Translate"),
                  ),
                ],
              ),

              //labelText: output.isNotEmpty ? output : 'Translation will appear here',
              // const SizedBox(height: 20),
              // TextFormField(
              //   decoration: InputDecoration(
              //     labelText: output.isNotEmpty ? output : 'Translation will appear here',  // Show translated text as label
              //     labelStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 20),
              //     border: const OutlineInputBorder(borderSide: BorderSide(color: Colors.amber, width: 1),),  // Optional: Add a border
              //   ),
              //
              //   maxLines: null,
              // ),
              const SizedBox(height: 20),
              Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width * 0.9, // 90% of the screen width
                child: TextFormField(
                  controller: TextEditingController(text: output),
                  // Set the controller with the translated text
                  readOnly: true,
                  // Make the field read-only so users can copy but not edit
                  minLines: 7,
                  maxLines: null,
                  // Allow the box to expand as needed
                  decoration: InputDecoration(
                    //       labelText: 'Please enter or speak your text...',
                    //       labelStyle: TextStyle(fontSize: 20, color: Colors.black),  // Increased font size
                    //       border: OutlineInputBorder(
                    //         borderSide: BorderSide(color: Color(0xFFFFB300), width: 1),
                    //       ),
                    //       enabledBorder: OutlineInputBorder(
                    //         borderSide: BorderSide(color: Color(0xFFFFB300), width: 1),
                    //       ),
                    //       errorStyle: TextStyle(color: Colors.red, fontSize: 15),
                    //     ),
                    //   ),
                    // ),
                    labelText: output.isEmpty
                        ? 'Translation will appear here'
                        : null, // Show the hint text when output is empty
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFFFB300), width: 5),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFFFB300), width: 5),
                    ),// Optional: Add a border
                  ),
                  style: const TextStyle(
                    fontSize: 20,
                    color: Color(0xFFFFB300),
                  ),
                ),
              ),


              // const SizedBox(height: 20),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     ElevatedButton(
              //       style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFB300)),
              //       onPressed: () {
              //         translate(languageController.text.trim());
              //       },
              //       child: const Text("Translate"),
              //     ),
              //     const SizedBox(width: 10),
              //     ElevatedButton(
              //       style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFB300)),
              //       onPressed: isListening ? stopListening : startListening,
              //       child: Text(isListening ? "Stop Listening" : "Start Speaking"),
              //     ),
              //   ],
              // ),
              const SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFB300)),
                    onPressed: () {
                      if (output.isNotEmpty) {
                        systemSpeak(
                            output); // Speak the translated text when button is pressed
                      }
                    },
                    child: const Text("Play Translation"),
                  ),
                  const SizedBox(width: 10,),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFB300)),
                    onPressed: () {
                      setState(() {
                        languageController.clear();
                        output = '';
                      });
                    },
                    child: const Text("Clear"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }





  Widget _buildLanguageDropdown(String currentLanguage,
      ValueChanged<String?> onChanged) {
    return DropdownButton<String>(
      hint: Row(
        children: [
          if (languages[currentLanguage] != null)
            CountryFlag.fromCountryCode(
              languages[currentLanguage]!, // Country code
              height: 20,
              width: 20,
            ),
          const SizedBox(width: 8),
          Text(currentLanguage, style: const TextStyle(color: Colors.black)),
        ],
      ),
      dropdownColor: Color(0xFFFFE57F),
      items: languages.keys.map((String languageName) {
        return DropdownMenuItem(
          value: languageName,
          child: Row(
            children: [
              CountryFlag.fromCountryCode(
                languages[languageName]!, // Country code
                height: 20,
                width: 20,
              ),
              const SizedBox(width: 8),
              Text(languageName),
            ],
          ),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }
}